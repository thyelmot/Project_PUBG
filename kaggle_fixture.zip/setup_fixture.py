from pathlib import Path
import json, sys, yaml

sys.dont_write_bytecode = True
code = Path(CODE_INPUT).resolve()
source = Path(FIXTURE_INPUT).resolve()
target = Path(PUBG_PROJECT_ROOT).resolve()
if Path("/kaggle/input").is_dir() and not target.is_relative_to(Path("/kaggle/working").resolve()):
    raise ValueError("Trên Kaggle chỉ chuẩn bị project trong working, không ghi vào Input")
if EXECUTION_MODE != "development" or ALLOW_FULL_DATA:
    raise ValueError("Gói này chỉ dành cho development, không full-data")
if not isinstance(SOURCE_VERSION, int) or SOURCE_VERSION < 1:
    raise ValueError("Nhập số version Dataset fixture đã gắn, không đoán")
if target.exists() and any(target.iterdir()):
    raise ValueError("Chọn working root mới/trống; không ghi đè kết quả hiện có")
sys.path.insert(0, str(code))
from src.io import digest, load_config
from src.kaggle_runtime import prepare_project, safe_file

manifest = json.loads(safe_file(source, "fixture_manifest.json").read_text(encoding="utf-8"))
if manifest.get("fixture_id") != "pubg-synthetic-fixture-v1" or manifest.get("scope") != "development":
    raise ValueError("Không phải gói fixture đã chuẩn bị")
expected = {"fixture_config.yaml", "agg_match_stats_0.csv", "agg_match_stats_1.csv",
            "kill_match_stats_0.csv", "kill_match_stats_1.csv"}
entries = manifest["entries"]
if len(entries) != len(expected) or {e["path"] for e in entries} != expected:
    raise ValueError("Gói fixture thiếu file hoặc có file trùng")
for entry in entries:
    path = safe_file(source, entry["path"])
    if path.stat().st_size != entry["bytes"] or digest(path) != entry["sha256"]:
        raise ValueError("Fixture checksum mismatch: " + entry["path"])
cfg = yaml.safe_load(safe_file(source, "fixture_config.yaml").read_text(encoding="utf-8"))
if cfg["source"]["dataset"] != manifest["fixture_id"] or cfg["rq3"]["selection_approved"]:
    raise ValueError("Sai cấu hình fixture hoặc đã mở final test")
prepare_project(code, target)
cfg["source"].update(directory=str(source), version=SOURCE_VERSION)
cfg["storage"]["project_root"] = str(target)
(target / "configs/project.yaml").write_text(yaml.safe_dump(cfg, allow_unicode=True, sort_keys=False), encoding="utf-8")
load_config(target)
SOURCE_DIRECTORY = str(source)
CODE_INPUT = RESUME_INPUT = ""
ALLOW_DATA_PROCESSING = True
print("Sẵn sàng cho S00/S01-S04, chỉ synthetic fixture:", manifest["expected"])
